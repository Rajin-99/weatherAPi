import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './App.css';

// Import images with updated paths
import CNtower from './cn.webp';
import Moon from './sunset.png';
import Sun from './sun.jpg';
import MorningImg from './morning.png';
import EveningImg from './evening.png';
import NightImg from './night.png';
import HumidityImg from './humidity.webp';
import PressureImg from './pressure.png';
import WindImg from './wind.png';
import LocationIcon from './location.png';

const WeatherApp = () => {
  const [weatherData, setWeatherData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [timeOfDay, setTimeOfDay] = useState(''); // State for time of day
  const [backgroundImg, setBackgroundImg] = useState(CNtower); // Set default CN Tower image
  const [currentTime, setCurrentTime] = useState(''); // State for current time

  // Coordinates for the location (latitude and longitude)
  const latitude = 43.7417;
  const longitude = -79.3733;

  // Function to update the current time
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const timeString = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      setCurrentTime(timeString);
    };
    
    updateTime(); // Update the time immediately on component load
    const intervalId = setInterval(updateTime, 1000); // Update every second

    return () => clearInterval(intervalId); // Clean up the interval on component unmount
  }, []);

  // Determine the time of day (morning, day, evening, night)
  useEffect(() => {
    const hour = new Date().getHours();
    
    if (hour >= 5 && hour < 10) {
      setTimeOfDay('Morning');
      setBackgroundImg(MorningImg); // Morning image
    } else if (hour >= 10 && hour < 16) {
      setTimeOfDay('Daytime');
      setBackgroundImg(Sun); // Daytime image
    } else if (hour >= 16 && hour < 20) {
      setTimeOfDay('Evening');
      setBackgroundImg(EveningImg); // Evening image
    } else {
      setTimeOfDay('Night');
      setBackgroundImg(NightImg); // Nighttime image
    }
  }, []);

  // Fetch weather data using latitude and longitude
  useEffect(() => {
    const fetchWeatherData = async () => {
      try {
        setLoading(true);
        const response = await axios.get(
          `https://weatherapi-com.p.rapidapi.com/current.json?q=${latitude},${longitude}`,
          {
            headers: {
              'x-rapidapi-host': 'weatherapi-com.p.rapidapi.com',
              'x-rapidapi-key': '05cd5c66d2mshf69f9c8a579a9afp1df834jsn9ba1e645fa51',
            },
          }
        );
        setWeatherData(response.data);
        setLoading(false);
      } catch (err) {
        setError(`Error fetching weather data: ${err.message}`);
        console.error(err);  // Log the detailed error to the console
        setLoading(false);
      }
    };
    fetchWeatherData();
  }, []);

  // Determine the appropriate weather condition
  const weatherCondition = weatherData?.current?.condition?.text?.toLowerCase();
  const isSunny = weatherCondition?.includes('sunny');
  const isClear = weatherCondition?.includes('clear');

  return (
    <div className="container"> {/* CN Tower background only in container */}
      <div className="weather-card">
        <div className="weather-info">
          <h1 className="location">
            <img src={LocationIcon} alt="Location Icon" className="location-icon" />
            Toronto, ON
          </h1>
          <p className="current-time"><strong>Current Time:</strong> {currentTime}</p> {/* Display current time */}
          <div className="weather-details">
            <div className="weather-section">
              <img src={HumidityImg} alt="Humidity" className="weather-icon" />
              <p><strong>Humidity:</strong> {weatherData?.current?.humidity}%</p>
            </div>
            <div className="weather-section">
              <img src={WindImg} alt="Wind Speed" className="weather-icon" />
              <p><strong>Wind Speed:</strong> {weatherData?.current?.wind_kph} kph</p>
            </div>
            <div className="weather-section">
              <img src={PressureImg} alt="Pressure" className="weather-icon" />
              <p><strong>Atmospheric Pressure:</strong> {weatherData?.current?.pressure_mb} hPa</p>
            </div>
          </div>
        </div>
        <div className="temperature-section">
          {/* Display time of day (Morning, Daytime, Evening, Night) */}
          <h2 className="time-of-day">{timeOfDay}</h2>
          {/* Weather condition (e.g., Sunny) placed above the temperature */}
          <h2 className="weather-condition">
            {weatherData?.current?.condition?.text}
          </h2>
          <h1 className="temperature">
            {weatherData?.current?.temp_c}°C
          </h1>
          {/* Sun/Moon image displayed only in this section */}
          <img
            src={isSunny && timeOfDay !== 'Night' ? Sun : Moon}
            alt={isSunny && timeOfDay !== 'Night' ? 'Sun' : 'Moon'}
            className="weather-image"
          />
        </div>
      </div>
    </div>
  );
  
};

export default WeatherApp;
